﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceChecker
{
    public static class Global
    {
        public static void AddError(Objects.ErrorObject err)
        {

        }
        public static bool CheckIfErrorRepeatedInAPeriod(Objects.ErrorObject err, TimeSpan sp)
        {
            return true;
        }
    }
}
