﻿public enum WaitType
{
    Nothing=0,ElementExists = 1, Clickable = 2, Visible = 3, WaitDisappear = 4,
    SleepBefore = 5, SleepAfter = 6, StopIfFound = 7, StopIfNotFound = 8
}