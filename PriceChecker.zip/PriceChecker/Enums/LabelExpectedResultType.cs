﻿public enum LabelExpectedResultType
{
    Nothing = 0, UrlChange = 1, UrlChangeContainHref = 2, SelfTextChange = 3, SelfCssClassChange = 4, SelfNotDisplayed = 5, SomethingDisplayed = 6,
    SomethingNotDisplayed = 7, SomethingEnabled = 8, SelfEnabled = 9, SelfDisabled = 10, SomethingDisabled = 11,
    UrlChangeEqualInputData = 12
}